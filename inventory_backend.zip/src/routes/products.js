const express = require("express");
const router = express.Router();
const productcontroller = require("../controllers/products.controller");
const imageUploader = require("../helpers/imageUploader");

router.get(
  "/products",
  productcontroller.productlist,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.get(
  "/setcookie",
  productcontroller.setcookie,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

router.get(
  "/products/list",
  productcontroller.productlistData,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

router.get(
  "/delete/products",
  productcontroller.GetDeletedProduct,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.post(
  "/products",
  imageUploader.upload.single("image_src"),
  productcontroller.createProducts,
  async (req, res, next) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res
      .status(400)
      .send({ message: error.message, status: "failed", statusCode: "400" });
  }
);
router.put(
  "/edit/products/:product_id",
  imageUploader.upload.single("image_src"),
  productcontroller.updateProducts,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.delete(
  "/permanent/delete/products/:product_id",
  productcontroller.PermentDeleteProduct,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.delete(
  "/delete/products/:product_id",
  productcontroller.DeleteProduct,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

router.get(
  "/products/:id",
  productcontroller.GetOneProductByID,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

module.exports = router;
