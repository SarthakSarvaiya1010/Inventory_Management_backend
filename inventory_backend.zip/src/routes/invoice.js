const express = require("express");
const router = express.Router();
const invoiceController = require("../controllers/invoice.controller");

router.get(
  "/invoicelist",
  invoiceController.InvoiceList,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

router.get(
  "/invoiceDeletelist",
  invoiceController.InvoiceDeleteList,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);

router.get(
  "/getinvoicepage",
  invoiceController.GetInvoicePage,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.post(
  "/addinvoice",
  invoiceController.AddInvoice,
  async (req, res, next) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res
      .status(400)
      .send({ message: error.message, status: "failed", statusCode: "400" });
  }
);
router.get(
  "/invoicelistbyid/:id",
  invoiceController.GetInvoiceListByID,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.put(
  "/UpdateInvoiceData/:invoice_id",
  invoiceController.UpdateInvoiceData,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.delete(
  "/PermanentDeleteInvoice/:invoice_id",
  invoiceController.PermentDeleteInvoice,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.delete(
  "/DeleteInvoice/:invoice_id",
  invoiceController.DeleteInvoice,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.delete(
  "/PermanentDeleteInvoice/:invoice_id",
  invoiceController.PermentDeleteInvoice,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.get(
  "/Invoice/pdf",
  invoiceController.InvoiceGetPdf,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.get(
  "/Invoice/checkpdf",
  invoiceController.checkpdf,
  (req, res) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res.status(400).send({ error: error.message });
  }
);
router.post(
  "/printinvoice",
  invoiceController.printInvoice,
  async (req, res, next) => {
    res.send(req.data);
  },
  (error, req, res, next) => {
    res
      .status(400)
      .send({ message: error.message, status: "failed", statusCode: "400" });
  }
);
module.exports = router;
